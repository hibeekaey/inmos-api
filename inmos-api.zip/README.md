# inmos-api
API for the Online Inventory Monitoring System
